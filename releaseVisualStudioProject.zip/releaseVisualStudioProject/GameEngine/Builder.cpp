#include "Builder.h"

void Builder::setAtrributes(string type, string color)
{
	_name = type;
	_color = color;
}