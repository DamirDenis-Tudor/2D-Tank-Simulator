# Overview 

# Responsible for : 
- Running the gameloop .
- Actualizing game components .
- Handling events .
- Also for layering : 
   - Menu (if is active)
   - Map
   - SpecialObjects
   - Tanks
   - Animations
   - MiniMap
   - Texts

