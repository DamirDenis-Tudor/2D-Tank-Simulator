#include "Builder.h"

void Builder::setAtrributes(string type, string color)
{
	_type = type;
	_color = color;
}