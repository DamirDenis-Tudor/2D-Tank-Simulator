#include "RendererManager.h"

SDL_Renderer* RendererManager::_renderer = nullptr;
int RendererManager::_width = 0;
int RendererManager::_heigth = 0;