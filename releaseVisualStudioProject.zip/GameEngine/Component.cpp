#include "Component.h"

int Component::_counter = 0;
